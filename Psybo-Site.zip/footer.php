<footer>
	<div class="container">
			<div class="company-adress">
				<ul>
					<li>
						<p>V2 Tower</p>
						<p>Opposit Old Bus Stand,</p>
						<p>Pandikkad Road, Manjeri</p>
					</li>
					<li>
						<p>Phone: +04932-222222</p>
						<p>Email: info@psybotechnologies.com</p>
					</li>
				</ul>
			</div>
				<ul class="social-links">
					<li>
						<a class="facebook" href="https://www.facebook.com/psybotechnologies"></a>
					</li>
					<li>
						<a class="twitter" href="https://twitter.com/psybotech"></a>
					</li>
					<li>
						<a class="linkedin" href="https://www.linkedin.php"></a>
					</li>
					<li>
						<a class="gplus" href="https://plus.google.com/u/0/"></a>
					</li>
				</ul>	
		<div class="footer-details">
			<div class="site-details">
				<p>All Rights Recieved @ PSYBO Technologies PVT.LTD</p>
				<p>PSYBO Technologies <?php echo(date("Y")); ?></p>
			</div>
		</div>
	</div>
</footer>
